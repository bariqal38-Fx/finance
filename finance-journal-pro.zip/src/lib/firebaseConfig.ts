export const firebaseConfig = {
  projectId: 'gen-lang-client-0540907211',
  appId: '1:569859046213:web:c4f290ebf2ecad9dfddc2c',
  apiKey: 'AIzaSyDe0KOaSaWDwA1MbIAHq0Wc1OswG6Mzzb0',
  authDomain: 'gen-lang-client-0540907211.firebaseapp.com',
  storageBucket: 'gen-lang-client-0540907211.firebasestorage.app',
  messagingSenderId: '569859046213',
  oAuthClientId: '569859046213-homu2gar0sg27t0ie4drrutg0um5df77.apps.googleusercontent.com',
};

export default firebaseConfig;
